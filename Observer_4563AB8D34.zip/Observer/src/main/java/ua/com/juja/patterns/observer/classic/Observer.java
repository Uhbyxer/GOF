package ua.com.juja.patterns.observer.classic;

/**
 * Created by oleksandr.baglai on 03.09.2015.
 */
public interface Observer {

    void handleEvent(Object input);

}
