package ua.com.juja.patterns.helloWorld;

/**
 * Created by oleksandr.baglai on 17.12.2015.
 */
public class ToUpperCaseDecorator extends Decorator {

    public ToUpperCaseDecorator(Component component) {
        super(component);
    }

    @Override
    public void run(String message) {
        super.run(message.toUpperCase());
    }
}
