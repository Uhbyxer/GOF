package ua.com.juja.patterns.helloWorld;

/**
 * Created by oleksandr.baglai on 17.12.2015.
 */
public class HelloWorldHandler extends Handler {

    private final Command command;

    public HelloWorldHandler(Command command) {
        this.command = command;
    }

    @Override
    protected Request handleRequest(Request request) {
        String s = request.getMessage().toLowerCase();
        if (!s.contains("hello") || !s.contains("world")) {
            return request;
        }

        return command.change(request);
    }
}
