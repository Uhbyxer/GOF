package ua.com.juja.patterns.helloWorld;

/**
 * Created by oleksandr.baglai on 17.12.2015.
 */
public final class Request {

    private final String message;

    public Request(Request request) {
        this.message = request.getMessage();
    }

    public Request(String message) {
        this.message = message;
    }

    public String getMessage() {
        return message;
    }
}
