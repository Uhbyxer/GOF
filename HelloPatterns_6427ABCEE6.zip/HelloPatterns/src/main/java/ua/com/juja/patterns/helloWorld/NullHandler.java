package ua.com.juja.patterns.helloWorld;

/**
 * Created by oleksandr.baglai on 17.12.2015.
 */
public class NullHandler extends Handler {
    @Override
    protected Request handleRequest(Request request) {
        // do nothing
        return request;
    }
}
