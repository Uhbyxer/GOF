package ua.com.juja.patterns.helloWorld;

/**
 * Created by oleksandr.baglai on 03.09.2015.
 */
public interface Observable extends MyIterable<Observer> {

    void add(Observer observer);

    void remove(Observer observer);

    void notifyAll(String message);
}
