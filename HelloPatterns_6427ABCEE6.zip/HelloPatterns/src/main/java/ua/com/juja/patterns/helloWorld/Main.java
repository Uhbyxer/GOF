package ua.com.juja.patterns.helloWorld;

/**
 * Created by oleksandr.baglai on 17.12.2015.
 */
public class Main {
    public static void main(String[] args) {
        String message = "Hello World";
        FactoryMethod factory = new SadFactoryMethod();

        process(message, factory);
    }

    private static void process(String message, FactoryMethod factory) {
        Component component = RunnerBuilder
                .forStrategy(ConsoleStrategy.getInstance())
                .andStrategy(new InMemoryStrategy())
                .andStrategy(new InMemoryStrategy())
                .andStrategy(new InMemoryStrategy())
                .andHelloWorldCommand(new AddEmotionsCommand(factory))
                .andHandler(Handler.NULL)
                .andHandler(Handler.NULL)
                .andHandler(Handler.NULL)
                .andHandler(Handler.NULL)
                .andHandler(Handler.NULL)
                .andHandler(Handler.NULL)
                .andHandler(Handler.NULL)
                .andDecorator(ToUpperCaseDecorator.class)
                .andDecorator(ReplaceSpaceTo.class)
                .create();

        component.run(message);
    }
}
