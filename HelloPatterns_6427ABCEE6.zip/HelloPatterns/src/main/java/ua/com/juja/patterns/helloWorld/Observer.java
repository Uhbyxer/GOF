package ua.com.juja.patterns.helloWorld;

/**
 * Created by oleksandr.baglai on 03.09.2015.
 */
public interface Observer {

    void handle(String message);

}
