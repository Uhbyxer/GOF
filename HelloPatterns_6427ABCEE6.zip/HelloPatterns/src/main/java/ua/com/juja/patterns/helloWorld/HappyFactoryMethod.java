package ua.com.juja.patterns.helloWorld;

/**
 * Created by oleksandr.baglai on 17.12.2015.
 */
public class HappyFactoryMethod implements FactoryMethod {
    @Override
    public EmotionProduct getEmotion() {
        return new HappySmileEmotionProduct();
    }
}
