package ua.com.juja.patterns.helloWorld;

/**
 * Created by oleksandr.baglai on 17.12.2015.
 */
public interface Runner extends Component {
    void addTarget(Target target);

    void addHandler(Handler handler);
}
