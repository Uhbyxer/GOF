package ua.com.juja.patterns.helloWorld;

/**
 * Created by oleksandr.baglai on 17.12.2015.
 */
public class AddEmotionsCommand implements Command {
    private final FactoryMethod factory;

    public AddEmotionsCommand(FactoryMethod factory) {
        this.factory = factory;
    }

    @Override
    public Request change(Request request) {
        Request changed = new Request(request.getMessage()
                + factory.getEmotion().get());
        return changed;
    }
}
